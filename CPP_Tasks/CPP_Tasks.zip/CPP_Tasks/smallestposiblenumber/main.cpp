#include <iostream>
using namespace std;

int main() {
	int e= -2147483647;
	cout<<e;
}
