#include <cmath>
#include <iostream>
using namespace std;
int main ()
{
    int x,y;
    cout <<"Give a number: "<<endl;
    cin>> x;
    y=sqrt(x);
    cout<<"The squer root of "<<x<<" is "<<y<<endl;
 
}
