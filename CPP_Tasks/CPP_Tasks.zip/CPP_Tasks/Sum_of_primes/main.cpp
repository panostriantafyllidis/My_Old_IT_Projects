/*Write a program that finds whether a number is the sum of two primes : 
Hints :
 * find whether the numbers are prime inside function 
 * 
*/
#include <iostream>
using namespace std ;
//Check if its prime 
bool primecheck(int x)
{
    int i;
    bool prime=true;
    for( i=2 ; i<=x/2; i++)
        {
        if (x%i==0)
            {
                prime = false;
                break;
           
            }
        } 
    return prime ;  
}

int main ()
{
    int n, i;
    bool flag = false ;
    cout<<"Enter a positive integer :"<<endl;
    cin>>n;
    for(i=2 ; i<= n/2; ++i )
    {
        if ( primecheck(i))
        {
            if(primecheck(n-i))
            {
                cout <<n<<" = "<< i << " + "<< n-i<<endl;
                flag=true;
            }
        }
    }
    if (!flag)
    {
        cout<<n << " can't be expressed as sum of two prime numbers. "<<endl;
    }
}