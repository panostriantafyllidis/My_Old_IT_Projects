#include <vector>
#include <iostream>
using namespace std ;
int main()
{
    vector<float> vec(10);
    float sum=0 , average , max;
    cout <<"Give 10 float numbers: "<<endl;
    cin>>vec[0];
    max=vec[0];
    for (int i=1;i<10;i++)
    {
        cin>>vec[i];
        sum+=vec[i];
        if (vec[i]>max)
        {
            max=vec[i];
        }
    }
    average=sum / 10.0 ;
    cout<<"The average is :" <<average<<" and the max is : " <<max<<endl;
    cout<<vec.operator[](5);

}
