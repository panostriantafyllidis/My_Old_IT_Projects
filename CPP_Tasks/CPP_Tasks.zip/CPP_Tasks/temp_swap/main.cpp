#include <iostream>
using namespace std;
int main ()
{
 float F ,C;
cout << "Type the temperature"<<endl;
cin>>F;
C=5*(F-32)/9;
cout <<"The tempersture in "<< C << "C" <<endl;   
}