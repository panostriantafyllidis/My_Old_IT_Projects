#include "iostream"
#include <cmath>
using namespace std;

class ComplexNumber
{
private :
	float x,y,CN,i;
public:
void setx(float a)
	{
		x = a;
	}
void sety(float b)
{
    y = b;
} 
float getCN()
{
return (x + pow(y,i)) ;
	}
	void operator++ ()
	{
		y--;
		x--;
	}
	ComplexNumber operator - (ComplexNumber CN)
	{
			ComplexNumber NewCN;
			NewCN.setx = this->setx - CN.setx;
			NewCN.sety = this->sety - CN.sety;
			return NewCN;
	}
	
};

int main()
{
	float x, y, z,f ;
	ComplexNumber CN1;
	cout << "Give the two numbers for the 1rst complex number :" << endl;
	cin >> x >> y;
	CN1.setx(x);
	CN1.sety(y);
	cout << CN1.getCN() << endl;
	ComplexNumber CN2;
	cout << "Give the two numbers for the 1rst complex number :" << endl;
	cin >> z >> f;
	CN2.setx(z);
	CN2.sety(f);
	cout << CN2.getCN() << endl;
	ComplexNumber CN3;
	CN3 = CN1 - CN2;
	cout<<"The 3rd , new complex number is :" << CN3.getCN << endl;
    return 0;
}

