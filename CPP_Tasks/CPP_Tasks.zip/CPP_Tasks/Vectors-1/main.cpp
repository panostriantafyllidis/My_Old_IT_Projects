#include <vector>
#include <iostream>
using namespace std ;
int main()
{
    vector<float> example(10);
    cout <<"Give 10 float numbers: "<<endl;
    for (int i=0;i<10;i++)
    {
        cin>>example[i];
    }
    for ( int i=0;i<10 ;i++)
    {
        cout<<example[i]<<endl;
    }

}
