#include <vector>
#include <iostream>
using namespace std ;
int main()
{
    vector<int> vec;
    vec.push_back(-5);
    vec.push_back(4);
    vec.push_back(76);
    vec.push_back(57);
    vec.push_back(67);
    vec.push_back(55);
    vec.pop_back();
    vec.push_back(5);
    cout<<vec.size()<<" "<<vec.empty()<<endl;
    vec.clear();
    cout<<vec.size()<<" "<<vec.empty()<<endl;
}
