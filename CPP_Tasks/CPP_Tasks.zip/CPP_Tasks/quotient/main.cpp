#include <iostream>
using namespace std;
int main()
{
double x,y,w;
cout <<"Give two numberz"<<endl;
cin>>x>>y;
if (y!=0)
w=x/y ;   
cout <<w<<endl;
}
