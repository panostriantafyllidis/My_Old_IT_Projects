/* Declare a 2D vector of 2 rows and 3 cols : */
#include <vector>
#include <iostream>
using namespace std ;
int main()
{
    vector<vector<int> >  list(2,vector<int>(3));
    for (int i=0 ; i<2 ; i++)
    {
        for( int j=0 ; j<3 ; j++)
        {
            cin>>list[i][j];
        }
    }
    for (int i=0 ; i<2 ; i++)
    {
        for( int j=0 ; j<3 ; j++)
        {
           cout<< list[i][j];
        }
        cout<<endl;
    }
}
